from setuptools import setup

setup(name='distributions_delicious',
      version='0.1',
      description='Gaussian distributions',
      packages=['distributions_delicious'],
      zip_safe=False)
